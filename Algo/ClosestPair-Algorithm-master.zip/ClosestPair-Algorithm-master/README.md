# ClosestPair.py
Closest Pair Algorithm, which takes a txt file of points, and finds the two points that are closest to each other in distance
The project returns the two points, and the calculated distance between those points.
